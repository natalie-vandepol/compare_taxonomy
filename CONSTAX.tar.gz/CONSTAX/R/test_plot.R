#!/usr/bin/env Rscript

pdf("test_plot.pdf")
plot(rnorm(100)) 
dev.off()


