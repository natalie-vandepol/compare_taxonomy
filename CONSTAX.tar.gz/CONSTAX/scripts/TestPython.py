#!/usr/bin/python

print("This line will be printed.")
